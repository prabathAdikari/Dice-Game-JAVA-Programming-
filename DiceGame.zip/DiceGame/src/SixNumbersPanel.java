import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

//User Interface for 1 player game
public class SixNumbersPanel extends JPanel implements ActionListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2542151432341106032L;
	private JTextField[] numsRolledTextFields;
    private JTextField rollingNumberTextField;
    private JTextArea txtMsgArea;
    private Player player;
    private JButton btnRoll;
    
  //Constructor Class which will be used to initiate the object
    public SixNumbersPanel() {
    	this.setOpaque(true);
    	this.setBackground(new Color(19, 173, 212));
    	this.setLayout(new FlowLayout());
    	this.add(new JLabel("Number between 1 to 6 will be rolled by Dice"));
        this.add(new JLabel("in each of the follwing text fields"));
        this.numsRolledTextFields = new JTextField[6];
        for (int i = 0; i < this.numsRolledTextFields.length; ++i) {
            this.add(this.numsRolledTextFields[i] = new JTextField(3));
        }
        this.btnRoll = new JButton("Roll the Die");
        btnRoll.addActionListener(this);
        this.add(btnRoll);
        this.add(this.rollingNumberTextField = new JTextField(3));
        (this.txtMsgArea = new JTextArea(15, 15)).setForeground(Color.BLUE);
        this.add(this.txtMsgArea);
        this.player = new Player();
    }
    
    //Button Click Event
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		int rolledValue = this.player.playGame();
        if (rolledValue == -1) {
            return;
        }
        this.rollingNumberTextField.setText(rolledValue + "");
        for (int i = 0; i < this.numsRolledTextFields.length; ++i) {
            if (this.player.getRolledNums()[i] != 0) {
                this.numsRolledTextFields[i].setText(this.player.getRolledNums()[i] + "");
            }
        }
        if (this.player.isAllNumsRolled()) {
        	this.txtMsgArea.setForeground(Color.RED);
            this.txtMsgArea.setText("\nCongratulations! You took only " + player.getTotalRolls() + " rolls to get all the numbers");
        }
        else {
            this.txtMsgArea.setText("\nNumber of rolls: " + this.player.getTotalRolls());
        }
	}

}
