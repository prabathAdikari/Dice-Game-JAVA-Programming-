import javax.swing.JFrame;

//Driver Class to Test One Player Game
public class DisplaySixNumbersPanel {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JFrame w1 = new JFrame("Six Numbers Game");
        SixNumbersPanel myPanel = new SixNumbersPanel();
        w1.add(myPanel);
        w1.setSize(450, 350);
        w1.setVisible(true);
        w1.setDefaultCloseOperation(3);
	}

}
