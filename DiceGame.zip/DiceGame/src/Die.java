import java.util.Random;

//Class which will generate a random number between 1 - 6 
public class Die {

	private Random generateNumber;
	
	//Constructor Class which will create a instance
	public Die() {
		this.generateNumber = new Random();
	}
	
	//Method which will generate the random number between 1 - 6
	public int RollDice() {
		return this.generateNumber.nextInt(6) + 1;
	}
}
