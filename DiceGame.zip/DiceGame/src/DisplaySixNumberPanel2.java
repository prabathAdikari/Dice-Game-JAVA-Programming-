import java.awt.GridLayout;

import javax.swing.JFrame;

//Driver Class to Test Two Player Game
public class DisplaySixNumberPanel2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JFrame w1 = new JFrame("Six Numbers Game");
        w1.setLayout(new GridLayout(1, 2));
        SixNumbersPanel2 player1Panel = new SixNumbersPanel2();
        SixNumbersPanel2 player2Panel = new SixNumbersPanel2();
        player1Panel.newGame(player2Panel);
        player2Panel.newGame(player1Panel);
        player1Panel.enable();
        player2Panel.disable();
        w1.add(player1Panel);
        w1.add(player2Panel);
        w1.setSize(900, 300);
        w1.setVisible(true);
        w1.setDefaultCloseOperation(3);

	}

}
