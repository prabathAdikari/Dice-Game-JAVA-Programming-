//Represent the user
public class Player {
		//Attributes of the Player Class
		private int[] alreadyRolledNums;
		private int rollsCount;
		private int rolledNumbers;
		private Die die;
		
		//Constructor Class
		public Player() {
			this.alreadyRolledNums = new int[6];
			this.rollsCount = 0;
			this.rolledNumbers = 0;
			this.die = new Die();
		}
		
		//Check whether number is already inserted to the list
		private boolean isalreadyRolledNum(int number) {
			for(int i = 0; i < alreadyRolledNums.length; i++) {
				if(this.alreadyRolledNums[i] == number) {
					return true;
				}
			}
			return false;
		}
		
		//Add the numbers to the List
		private void addNumberToList(int number) {
			for(int i = 0; i < this.alreadyRolledNums.length; i++) {
				if(this.alreadyRolledNums[i] == 0) {
					this.alreadyRolledNums[i] = number;
					break;
				}
			}
		}
		
		//Get Numbers saved in list
		public int[] getRolledNums() {
			return this.alreadyRolledNums;
		}
		
		//Get total rolls
		public int getTotalRolls() {
			return this.rollsCount;
		}
		
		//Check all the numbers between 1-6 rolled
		public boolean isAllNumsRolled() {
			return this.rolledNumbers == 6;
		}
		
		//Play the game
		
		public int playGame() {
			if(this.rolledNumbers == 6) {
				return -1;
			}
			else {
				int rolledNumber = this.die.RollDice();
				if(!this.isalreadyRolledNum(rolledNumber)) {
					this.addNumberToList(rolledNumber);
					++this.rolledNumbers;
				}
				++this.rollsCount;
				return rolledNumber;
			}
		}
}
