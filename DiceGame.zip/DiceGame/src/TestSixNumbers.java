//Console class to test the Player and Die instances
public class TestSixNumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Player player = new Player();
		while(!player.isAllNumsRolled()) {
			int rolledValue = player.playGame();
			System.out.println("Rolled Number - " + rolledValue);
			System.out.print("Numbers you rolled so far - ");
			for(int i = 0; i < player.getRolledNums().length; i++) {
				if(player.getRolledNums()[i] != 0) {
					System.out.print(player.getRolledNums()[i] + " ");
				}
			}
			System.out.println();
		}
		System.out.println("Congratulations! You took only " + player.getTotalRolls() + " rolls to get all the numbers");
	}

}
