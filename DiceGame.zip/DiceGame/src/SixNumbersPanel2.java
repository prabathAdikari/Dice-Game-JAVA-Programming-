import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

//User Interface for 2 Players
public class SixNumbersPanel2 extends JPanel implements ActionListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1948338467858713506L;
	private JTextField[] numsRolledTextFields;
    private JTextField rollingNumberTextField;
    private JTextArea txtMsgArea;
    private Player player;
    private JButton btnRoll;
    private JButton btnNew;
    private SixNumbersPanel2 player2;
    
    //Constructor Class which will be used to initiate the object
    public SixNumbersPanel2() {
        this.setOpaque(true);
        this.setBackground(new Color(19, 173, 212));
        this.setLayout(new FlowLayout());
        this.add(new JLabel("Dice will roll a number between 1 to 6 and will appear"));
        this.add(new JLabel("in each of the follwing text fields"));
        this.numsRolledTextFields = new JTextField[6];
        for (int i = 0; i < this.numsRolledTextFields.length; ++i) {
            this.add(this.numsRolledTextFields[i] = new JTextField(3));
        }
        (this.btnRoll = new JButton("Roll Die")).addActionListener(this);
        this.add(this.btnRoll);
        this.add(this.rollingNumberTextField = new JTextField(3));
        (this.txtMsgArea = new JTextArea(10, 15)).setForeground(Color.BLUE);
        this.add(this.txtMsgArea);
        (this.btnNew = new JButton("New Game")).addActionListener(this);
        this.btnNew.setVisible(false);
        this.add(this.btnNew);
    }
    
    //Create a new game
    public void newGame(SixNumbersPanel2 player2) {
        this.player = new Player();
        this.player2 = player2;
        this.txtMsgArea.setText("");
        this.rollingNumberTextField.setText("");
        this.btnNew.setVisible(false);
        for (int i = 0; i < this.numsRolledTextFields.length; ++i) {
            this.numsRolledTextFields[i].setText("");
        }
    }
	
    //Capturing button click event of roll button and new game button
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getActionCommand().equalsIgnoreCase("New Game")) {
            this.disable();
            this.player2.enable();
            this.newGame(this.player2);
            this.player2.newGame(this);
        }
        else {
            final int rolledValue = this.player.playGame();
            if (rolledValue == -1) {
                return;
            }
            this.rollingNumberTextField.setText(rolledValue + "");
            for (int i = 0; i < this.numsRolledTextFields.length; ++i) {
                if (this.player.getRolledNums()[i] != 0) {
                    this.numsRolledTextFields[i].setText(this.player.getRolledNums()[i] + "");
                }
            }
            if (this.player.isAllNumsRolled()) {
            	this.txtMsgArea.setText("\nCongratulations! You took only " + player.getTotalRolls() + " rolls to get all the numbers");
                this.btnNew.setVisible(true);
            }
            else {
            	this.txtMsgArea.setText("\nNumber of rolls: " + this.player.getTotalRolls());
                this.disable();
                this.player2.enable();
            }
        }
	}
	
	//Hide Button
	@Override
    public void disable() {
        this.btnRoll.setEnabled(false);
    }
    
	//Show Button
    @Override
    public void enable() {
        this.btnRoll.setEnabled(true);
    }

}
